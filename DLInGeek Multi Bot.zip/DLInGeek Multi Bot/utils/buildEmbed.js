export function buildEmbed(media, user) {
  const isMovie = media.mediaType === 'movie';
  const year = (media.releaseDate || media.firstAirDate || '????').split('-')[0];

  return {
    color: 0x00AE86,
    title: `${isMovie ? "🎬" : "📺"} ${media.title || media.name} (${year})`,
    description: media.overview || 'No description available.',
    thumbnail: { url: `https://image.tmdb.org/t/p/w500${media.posterPath}` },
    fields: [
      {
        name: isMovie ? 'Release Date' : 'First Air Date',
        value: media.releaseDate || media.firstAirDate || 'Unknown',
        inline: true
      },
      {
        name: 'Status',
        value: media.status || 'Not Requested',
        inline: true
      },
      ...(isMovie ? [] : [{
        name: 'Seasons',
        value: media.seasons?.length?.toString() || 'N/A',
        inline: true
      }]),
      {
        name: 'Requested By',
        value: `<@${user.id}>`
      }
    ],
    footer: { text: `Overseerr · ${isMovie ? "Movie" : "Series"} Request` }
  };
}
