import fetch from 'node-fetch';
import { SlashCommandBuilder, EmbedBuilder } from 'discord.js';

const DELUGE_URL = process.env.DELUGE_URL;
const DELUGE_PASSWORD = process.env.DELUGE_PASSWORD;

export const data = new SlashCommandBuilder()
  .setName('status')
  .setDescription('Shows current download status from Deluge');

async function delugeRequest(method, params = []) {
  // Login to get session cookie
  const loginResponse = await fetch(`${DELUGE_URL}/json`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      method: 'auth.login',
      params: [DELUGE_PASSWORD],
      id: 1,
    }),
    credentials: 'include',
  });

  if (!loginResponse.ok) throw new Error('Deluge login failed');

  const loginData = await loginResponse.json();
  if (!loginData.result) throw new Error('Deluge login rejected');

  // Get the cookie from login response
  const cookie = loginResponse.headers.get('set-cookie') || '';

  // Now get the torrent status
  const response = await fetch(`${DELUGE_URL}/json`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'Cookie': cookie,
    },
    body: JSON.stringify({
      method,
      params,
      id: 2,
    }),
    credentials: 'include',
  });

  if (!response.ok) throw new Error('Deluge API call failed');

  const data = await response.json();
  return data.result;
}

export async function execute(interaction) {
  try {
    // Use core.get_torrents_status with empty filter and requested fields
    const result = await delugeRequest('core.get_torrents_status', [{}, ['name', 'progress', 'state']]);
    const torrents = result;

    if (!torrents || Object.keys(torrents).length === 0) {
      return interaction.reply('📭 No active downloads.');
    }

    const embed = new EmbedBuilder()
      .setTitle('📥 DLInGeek Current Downloads')
      .setColor(0x1E90FF);

    for (const torrent of Object.values(torrents)) {
      embed.addFields({
        name: torrent.name,
        value: `Progress: ${torrent.progress.toFixed(1)}% | Status: ${torrent.state}`,
      });
    }

    await interaction.reply({ embeds: [embed] });
  } catch (error) {
    console.error('Error in status command:', error);
    await interaction.reply('❌ Failed to fetch Deluge status.');
  }
}
