import { SlashCommandBuilder } from 'discord.js';
import fetch from 'node-fetch';
import dotenv from 'dotenv';

dotenv.config();

export const data = new SlashCommandBuilder()
  .setName('requests')
  .setDescription('Request a movie or show')
  .addStringOption(option =>
    option.setName('title')
      .setDescription('Movie or show title')
      .setRequired(true)
  );

export async function execute(interaction) {
  const title = interaction.options.getString('title');
  const apiKey = process.env.OMDB_API_KEY;

  if (!apiKey) {
    await interaction.reply({ content: '❌ OMDb API key is not configured.', ephemeral: true });
    return;
  }

  try {
    const response = await fetch(`http://www.omdbapi.com/?t=${encodeURIComponent(title)}&apikey=${apiKey}`);
    const data = await response.json();

    if (data.Response === 'False') {
      await interaction.reply({ content: `❌ "${title}" is not a valid movie or show. Request unsuccessful.`, ephemeral: true });
      return;
    }

    await interaction.reply({ content: `✅ Your request for "${data.Title}" (${data.Year}) was successful!`, ephemeral: true });

  } catch (error) {
    console.error('Request command error:', error);
    await interaction.reply({ content: '❌ Something went wrong while checking the movie.', ephemeral: true });
  }
}
